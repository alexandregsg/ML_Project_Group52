import numpy as np
import pickle
import streamlit as st

# Loading the saved model

file_path = "C:/Users/alexg/Ambiente de Trabalho/Mestrado Data Science NOVA IMS/1st semester/Machine Learning/Project_github/ML_Project_Group52/project/Deployment of ML model/trained_model.sav"


loaded_model = pickle.load(open(file_path, 'rb'))


outcome_mapping = {
    2: "NON-COMP",
    4: "TEMPORARY",
    3: "MED ONLY",
    5: "PPD SCH LOSS",
    1: "CANCELLED",
    6: "PPD NSL",
    8: "DEATH",
    7: "PTD"
}

selected_features = ['num__Age at Injury',
 'onehot__Attorney/Representative_N',
 'num__Average Weekly Wage',
 'label__Carrier Name',
 'num__Accident_Day',
 'onehot__Gender_M',
 'onehot__COVID-19 Indicator_N',
 'label__Zip Code',
 'label__Industry Code Description',
 'label__Nature of Injury Category',
 'label__Body Part Category']

# Creating a function to prediction

def insurance_prediction(input_data):
    """
    Predict the outcome based on user input.
    """
    input_data_np = np.asarray(input_data, dtype=float)  # Convert input data to numpy array
    input_data_reshaped = input_data_np.reshape(1, -1)  # Reshape for the model
    
    # Make prediction
    prediction = loaded_model.predict(input_data_reshaped)
    
    # Map the prediction to the class label
    predicted_label = outcome_mapping.get(prediction[0], "Unknown")
    return f"The predicted outcome is: {predicted_label}"



# Main function for Streamlit app
def main():
    """
    Streamlit app for predicting insurance outcomes.
    """
    # App title
    st.title("To Grant or Not to Grant - ML Project")

    # Dictionary to store user inputs
    user_inputs = {}
    
    # Generate input fields for each feature
    for feature in selected_features:
        user_inputs[feature] = st.text_input(f"Enter {feature}")

    # Placeholder for prediction result
    label_prediction = ""

    # Create a button to trigger prediction
    if st.button("Insurance test result"):
        try:
            # Collect user input and pass to prediction function
            input_data = list(user_inputs.values())
            label_prediction = insurance_prediction(input_data)
        except ValueError:
            label_prediction = "Invalid input! Please ensure all inputs are numeric and correctly formatted."

    # Display the prediction result
    st.success(label_prediction)


if __name__ == '__main__':
    main()




    


