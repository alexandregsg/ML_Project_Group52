import numpy as np
import pickle



# Loading the saved model

file_path = "C:/Users/alexg/Ambiente de Trabalho/Mestrado Data Science NOVA IMS/1st semester/Machine Learning/Project_github/ML_Project_Group52/project/Deployment of ML model/trained_model.sav"

loaded_model = pickle.load(open(file_path, 'rb'))



# input data

# Define the mapping for outcomes
outcome_mapping = {
    0: "CANCELLED",
    1: "NON-COMP",
    2: "MED ONLY",
    3: "TEMPORARY",
    4: "PPD SCH LOSS",
    5: "PPD NSL",
    6: "PTD",
    7: "DEATH"
}


input_data = () # nr of features that are being used in the model

input_data_np = np.asarray(input_data)

input_data_reshaped = input_data_np.reshape(1, -1)

prediciton = loaded_model.predict(input_data_reshaped)  


# Make prediction
prediction = loaded_model.predict(input_data_reshaped)

# Get the class label from the mapping
predicted_label = outcome_mapping[prediction[0]]

# Print the predicted class
print(f"The predicted outcome is: {predicted_label}")